import java.awt.event.ActionEvent;

public abstract class MyEvent {
    public abstract void invoke(ActionEvent e);
}

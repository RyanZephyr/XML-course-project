public class NewMovie implements Comparable<NewMovie> {
    private String country;
    private int ranking;
    private int release_year;
    private String name;
    private String review;
    private String rating;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getRanking() {
        return ranking;
    }

    public void setRanking(int ranking) {
        this.ranking = ranking;
    }

    public int getRelease_year() {
        return release_year;
    }

    public void setRelease_year(int release_year) {
        this.release_year = release_year;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    @Override
    public int compareTo(NewMovie o) {
        if (this.ranking < o.getRanking())
            return -1;
        else if (this.ranking > o.getRanking())
            return 1;
        else
            return 0;
    }
}

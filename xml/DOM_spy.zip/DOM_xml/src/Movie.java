public class Movie implements Comparable<Movie> {
    private int ranking;
    private String IMDb;
    private String country;
    private int release_year;
    private String img;
    private String Chinese_name;
    private String English_name;
    private String[] director = new String[3];
    private String[] actor = new String[3];
    private String[] genre = new String[3];
    private String[] language = new String[3];
    private String introduction;
    private String review;
    private String rating;
    private int number;

    int getRanking() {
        return ranking;
    }

    void setRanking(int ranking) {
        this.ranking = ranking;
    }

    public String getIMDb() {
        return IMDb;
    }

    void setIMDb(String IMDb) {
        this.IMDb = IMDb;
    }

    public String getCountry() {
        return country;
    }

    void setCountry(String country) {
        this.country = country;
    }

    public int getRelease_year() {
        return release_year;
    }

    void setRelease_year(int release_year) {
        this.release_year = release_year;
    }

    public String getImg() {
        return img;
    }

    void setImg(String img) {
        this.img = img;
    }

    public String getEnglish_name() {
        return English_name;
    }

    void setEnglish_name(String english_name) {
        English_name = english_name;
    }

    public String[] getDirector() {
        return director;
    }

    void setDirector(String director) {
        int i = 0;
        for (; i < 3; i++) {
            if (this.director[i] == null)
                break;
        }
        if (i == 3)
            return;
        this.director[i] = director;
    }

    public String[] getActor() {
        return actor;
    }

    void setActor(String actor) {
        int i = 0;
        for (; i < 3; i++) {
            if (this.actor[i] == null)
                break;
        }
        if (i == 3)
            return;
        this.actor[i] = actor;
    }

    public String[] getGenre() {
        return genre;
    }

    void setGenre(String genre) {
        int i = 0;
        for (; i < 3; i++) {
            if (this.genre[i] == null)
                break;
        }
        if (i == 3)
            return;
        this.genre[i] = genre;
    }

    public String[] getLanguage() {
        return language;
    }

    void setLanguage(String language) {
        int i = 0;
        for (; i < 3; i++) {
            if (this.language[i] == null)
                break;
        }
        if (i == 3)
            return;
        this.language[i] = language;
    }

    public String getRating() {
        return rating;
    }

    void setRating(String rating) {
        this.rating = rating;
    }

    public int getNumber() {
        return number;
    }

    void setNumber(int number) {
        this.number = number;
    }

    public String getChinese_name() {
        return Chinese_name;
    }

    void setChinese_name(String chinese_name) {
        Chinese_name = chinese_name;
    }

    String getIntroduction() {
        return introduction;
    }

    void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getReview() {
        return review;
    }

    void setReview(String review) {
        this.review = review;
    }

    void setDirector(String director[]) {
        this.director = director;
    }

    void setGenre(String genre[]) {
        this.genre = genre;
    }

    void setLanguage(String language[]) {
        this.language = language;
    }

    void setActor(String actor[]) {
        this.actor = actor;
    }

    @Override
    public int compareTo(Movie o) {
        if (this.release_year < o.getRelease_year())
            return -1;
        else if (this.release_year > o.getRelease_year())
            return 1;
        else
            return 0;
    }

}

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Dom_xml {
    public static void newXMLByCountry(DocumentBuilder db) throws IOException, SAXException {
        Document doc = db.parse(Dom_xml.class.getResourceAsStream("movies.xml"));
        NodeList nList = doc.getElementsByTagName("movie");
        //新建的xml文档
        Document newDoc = db.newDocument();
        Element newRoot = newDoc.createElement("countries");
        newDoc.appendChild(newRoot);
        //判断一共有多少个不同的国家
        String[] countryStr = new String[10];
        int num = 0;
        for (int i = 0; i < nList.getLength(); i++) {
            Element movie = (Element) nList.item(i);
            String cnt = movie.getAttribute("country");
            int j = 0;
            for (; j < num; j++) {
                if (cnt.equals(countryStr[j]))
                    break;
            }
            if (j == num) {//之前未存有该国家
                countryStr[num] = cnt;
                num++;
            }
        }

        for (int cn = 0; cn < num; cn++) {
            Element country = newDoc.createElement("country");
            country.setAttribute("name", countryStr[cn]);
            for (int i = 0; i < nList.getLength(); i++) {
                Element movie = (Element) nList.item(i);
                String currentCountry = movie.getAttribute("country");
                if (currentCountry.equals(countryStr[cn])) {
                    String ranking = movie.getAttribute("ranking");
                    String release_year = movie.getAttribute("release_year");
                    //电影标签
                    Element newMovie = newDoc.createElement("movie");
                    newMovie.setAttribute("ranking", ranking);
                    newMovie.setAttribute("release_year", release_year);
                    //名字标签
                    String chinese_name = movie.getElementsByTagName("Chinese_name").item(0).getFirstChild().getNodeValue();
                    Element name = newDoc.createElement("name");
                    Text t1 = newDoc.createTextNode(chinese_name);
                    name.appendChild(t1);
                    //review标签
                    String rating = movie.getElementsByTagName("review").item(0).getAttributes().getNamedItem("rating").getNodeValue();
                    String reviewText = movie.getElementsByTagName("review").item(0).getFirstChild().getNodeValue();
                    Text t2 = newDoc.createTextNode(reviewText);
                    Element review = newDoc.createElement("review");
                    review.setAttribute("rating", rating);
                    review.appendChild(t2);

                    newMovie.appendChild(name);
                    newMovie.appendChild(review);
                    country.appendChild(newMovie);
                }
                newRoot.appendChild(country);
            }
        }

        writeXML(newDoc, "new.xml");
    }

    public static List<Movie> getXML(Document doc) throws SAXException, IOException {
        NodeList nList = doc.getElementsByTagName("movie");
        List<Movie> movies = new ArrayList<>();
        for (int i = 0; i < nList.getLength(); i++) { //从xml文档中将所有的movie取出放入ArrayList
            Element movie = (Element) nList.item(i);
            int ranking = Integer.parseInt(movie.getAttribute("ranking"));
            String IMDb = movie.getAttribute("IMDb");
            String country = movie.getAttribute("country");
            int release_year = Integer.parseInt(movie.getAttribute("release_year"));
            String img = movie.getAttribute("img");
            String Chinese_name = movie.getElementsByTagName("Chinese_name").item(0).getFirstChild().getNodeValue();
            String English_name = movie.getElementsByTagName("English_name").item(0).getFirstChild().getNodeValue();
            String[] director = new String[3];
            String[] actor = new String[3];
            String[] genre = new String[3];
            String[] language = new String[3];
            director[0] = movie.getElementsByTagName("director").item(0).getFirstChild().getNodeValue();
            for (int j = 0; j < 3; j++) {
                actor[j] = movie.getElementsByTagName("actor").item(j).getFirstChild().getNodeValue();
                genre[j] = movie.getElementsByTagName("genre").item(0).getAttributes().getNamedItem("category").getNodeValue();
                language[j] = movie.getElementsByTagName("language").item(0).getAttributes().getNamedItem("category").getNodeValue();
            }
            String introduction = movie.getElementsByTagName("introduction").item(0).getFirstChild().getNodeValue();
            String review = movie.getElementsByTagName("review").item(0).getFirstChild().getNodeValue();
            String rating = movie.getElementsByTagName("review").item(0).getAttributes().getNamedItem("rating").getNodeValue();
            int number = Integer.parseInt(movie.getElementsByTagName("review").item(0).getAttributes().getNamedItem("number").getNodeValue());
            Movie movieTemp = new Movie();
            movieTemp.setRanking(ranking);
            movieTemp.setIMDb(IMDb);
            movieTemp.setCountry(country);
            movieTemp.setRelease_year(release_year);
            movieTemp.setImg(img);
            movieTemp.setGenre(genre);
            movieTemp.setLanguage(language);
            movieTemp.setRating(rating);
            movieTemp.setNumber(number);
            movieTemp.setChinese_name(Chinese_name);
            movieTemp.setEnglish_name(English_name);
            movieTemp.setDirector(director);
            movieTemp.setActor(actor);
            movieTemp.setIntroduction(introduction);
            movieTemp.setReview(review);
            movies.add(movieTemp);
        }
        return movies;
    }

    public static List<NewMovie> getNewXML(Document doc) throws SAXException, IOException {
        NodeList nList = doc.getElementsByTagName("movie");
        List<NewMovie> movies = new ArrayList<>();
        for (int i = 0; i < nList.getLength(); i++) {//从xml文档中将所有的movie取出放入ArrayList
            Element movie = (Element) nList.item(i);
            String country = movie.getParentNode().getAttributes().getNamedItem("name").getNodeValue();
            int ranking = Integer.parseInt(movie.getAttribute("ranking"));
            int release_year = Integer.parseInt(movie.getAttribute("release_year"));
            String name = movie.getElementsByTagName("name").item(0).getFirstChild().getNodeValue();
            String review = movie.getElementsByTagName("review").item(0).getFirstChild().getNodeValue();
            String rating = movie.getElementsByTagName("review").item(0).getAttributes().getNamedItem("rating").getNodeValue();
            NewMovie movieTemp = new NewMovie();
            movieTemp.setRanking(ranking);
            movieTemp.setRelease_year(release_year);
            movieTemp.setRating(rating);
            movieTemp.setReview(review);
            movieTemp.setName(name);
            movieTemp.setCountry(country);
            movies.add(movieTemp);
        }
        return movies;
    }

    public static void deleteMovie(Document doc, String movieName) {
        NodeList nList = doc.getElementsByTagName("movie");
        for (int i = 0; i < nList.getLength(); i++) {
            Element movie = (Element) nList.item(i);
            String Chinese_name = movie.getElementsByTagName("name").item(0).getFirstChild().getNodeValue();
            if (Chinese_name.equals(movieName)) {
                System.out.println("Catch");
                movie.getParentNode().removeChild(movie);
                i--;
            }
        }
        writeXML(doc, "new.xml");
    }

    public static void updateNodeText(Document doc, String movieName, String nodeName, String attr, String newText) {
        NodeList nList = doc.getElementsByTagName("movie");
        for (int i = 0; i < nList.getLength(); i++) {
            Element movie = (Element) nList.item(i);
            String Chinese_name = movie.getElementsByTagName("name").item(0).getFirstChild().getNodeValue().toString();
            if (Chinese_name.equals(movieName)) {
                if (nodeName != null) {
                    if (attr == null) {//不修改属性的值
                        movie.getElementsByTagName(nodeName).item(0).getFirstChild().setNodeValue(newText);
                    } else {
                        movie.getElementsByTagName(nodeName).item(0).getAttributes().getNamedItem(attr).setNodeValue(newText);
                    }
                }
            }
        }
        writeXML(doc, "new.xml");
    }

    private static void writeXML(Document doc, String file) {
        try {
            Transformer t = TransformerFactory.newInstance().newTransformer();
            t.setOutputProperty("indent", "yes");
            t.transform(new DOMSource(doc), new StreamResult(new FileOutputStream(file)));
        } catch (TransformerException | FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}

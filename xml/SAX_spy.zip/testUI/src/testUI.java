import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

import javax.swing.*;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.util.Objects;
import java.util.Vector;
/*
 * Created by JFormDesigner on Fri Apr 12 20:41:14 CST 2019
 */

public class testUI extends JFrame {
    private testUI() {
        initTable();
        initComponents();
    }

    private void button1ActionPerformed(ActionEvent e) {
        retrieve();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        label_low_rating = new JLabel();
        label_high_rating = new JLabel();
        label_low_year = new JLabel();
        label_high_year = new JLabel();
        label_country = new JLabel();
        label_number = new JLabel();
        label_low_ranking = new JLabel();
        label_high_ranking = new JLabel();
        lowRatingInput = new JTextField();
        highRatingInput = new JTextField();
        lowYearInput = new JTextField();
        highYearInput = new JTextField();
        countryInput = new JTextField();
        minRateNumInput = new JTextField();
        lowRankInput = new JTextField();
        highRankInput = new JTextField();
        label_order = new JLabel();
        comboBox = new JComboBox<>(new String[]{"", "Country", "Rating", "Genre"});
        btnSearch = new JButton();
        resultScrPane = new JScrollPane();
        resultTable = new JTable();

        //======== this ========
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridBagLayout());
        ((GridBagLayout) contentPane.getLayout()).columnWidths = new int[]{84, 129, 95, 90, 0};
        ((GridBagLayout) contentPane.getLayout()).rowHeights = new int[]{0, 45, 0, 42, 31, 123, 0};
        ((GridBagLayout) contentPane.getLayout()).columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0E-4};
        ((GridBagLayout) contentPane.getLayout()).rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0E-4};

        //---- label_low_rating ----
        label_low_rating.setText("最低评分");
        label_low_rating.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_low_rating, new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(10, 10, 5, 0), 0, 0));

        //---- label_high_rating ----
        label_high_rating.setText("最高评分");
        label_high_rating.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_high_rating, new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(10, 12, 5, 0), 0, 0));

        //---- label_low_year ----
        label_low_year.setText("最早年份");
        label_low_year.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_low_year, new GridBagConstraints(2, 0, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(10, 10, 5, -5), 0, 0));

        //---- label_high_year ----
        label_high_year.setText("最晚年份");
        label_high_year.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_high_year, new GridBagConstraints(3, 0, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(10, 10, 5, 0), 0, 0));

        //---- lowRatingInput ----
        lowRatingInput.setBorder(new MatteBorder(1, 1, 1, 1, Color.black));
        lowRatingInput.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
        lowRatingInput.setPreferredSize(new Dimension(80, 30));
        contentPane.add(lowRatingInput, new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 10, 5, 0), 0, 0));

        //---- highRatingInput ----
        highRatingInput.setBorder(new MatteBorder(1, 1, 1, 1, Color.black));
        highRatingInput.setPreferredSize(new Dimension(80, 30));
        contentPane.add(highRatingInput, new GridBagConstraints(1, 1, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 12, 5, 0), 0, 0));

        //---- lowYearInput ----
        lowYearInput.setBorder(new MatteBorder(1, 1, 1, 1, Color.black));
        lowYearInput.setPreferredSize(new Dimension(80, 30));
        contentPane.add(lowYearInput, new GridBagConstraints(2, 1, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 10, 5, -5), 0, 0));

        //---- highYearInput ----
        highYearInput.setBorder(new MatteBorder(1, 1, 1, 1, Color.black));
        highYearInput.setPreferredSize(new Dimension(80, 30));
        contentPane.add(highYearInput, new GridBagConstraints(3, 1, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 10, 5, 0), 0, 0));

        //---- label_country ----
        label_country.setText("国家");
        label_country.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_country, new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(10, 10, 5, 0), 0, 0));

        //---- label_number ----
        label_number.setText("最少评分人数");
        label_number.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_number, new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(10, 12, 5, 0), 0, 0));

        //---- label_low_ranking ----
        label_low_ranking.setText("最低排名");
        label_low_ranking.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_low_ranking, new GridBagConstraints(2, 2, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(10, 10, 5, -5), 0, 0));

        //---- label_high_ranking ----
        label_high_ranking.setText("最高排名");
        label_high_ranking.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_high_ranking, new GridBagConstraints(3, 2, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(10, 10, 5, 0), 0, 0));

        //---- countryInput ----
        countryInput.setBorder(new MatteBorder(1, 1, 1, 1, Color.black));
        countryInput.setPreferredSize(new Dimension(80, 30));
        contentPane.add(countryInput, new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 10, 5, 0), 0, 0));

        //---- minRateNumInput ----
        minRateNumInput.setBorder(new MatteBorder(1, 1, 1, 1, Color.black));
        minRateNumInput.setPreferredSize(new Dimension(80, 30));
        contentPane.add(minRateNumInput, new GridBagConstraints(1, 3, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 12, 5, 0), 0, 0));

        //---- lowRankInput ----
        lowRankInput.setBorder(new MatteBorder(1, 1, 1, 1, Color.black));
        lowRankInput.setPreferredSize(new Dimension(80, 30));
        contentPane.add(lowRankInput, new GridBagConstraints(2, 3, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 10, 5, -5), 0, 0));

        //---- highRankInput ----
        highRankInput.setBorder(new MatteBorder(1, 1, 1, 1, Color.black));
        highRankInput.setPreferredSize(new Dimension(80, 30));
        contentPane.add(highRankInput, new GridBagConstraints(3, 3, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 10, 5, 0), 0, 0));

        //---- label_order ----
        label_order.setText("按...排序");
        label_order.setFont(new Font("微软雅黑", Font.BOLD, 14));
        contentPane.add(label_order, new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.NONE,
                new Insets(0, 0, 5, 5), 0, 0));
        contentPane.add(comboBox, new GridBagConstraints(1, 4, 1, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 5, 5), 0, 0));

        //---- btnSearch ----
        btnSearch.setText("搜 索");
        btnSearch.setFont(new Font("微软雅黑", Font.BOLD, 14));
        btnSearch.addActionListener(this::button1ActionPerformed);
        contentPane.add(btnSearch, new GridBagConstraints(2, 4, 2, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 10, 5, 10), 0, 0));

        //======== resultScrPane ========
        {
            resultScrPane.setViewportView(resultTable);
        }
        contentPane.add(resultScrPane, new GridBagConstraints(0, 5, 4, 1, 0.0, 0.0,
                GridBagConstraints.CENTER, GridBagConstraints.BOTH,
                new Insets(0, 0, 0, 0), 0, 0));
        pack();
        setLocationRelativeTo(getOwner());
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    private JLabel label_low_rating;
    private JLabel label_high_rating;
    private JLabel label_low_year;
    private JLabel label_high_year;
    private JTextField lowRatingInput;
    private JTextField highRatingInput;
    private JTextField lowYearInput;
    private JTextField highYearInput;
    private JLabel label_country;
    private JLabel label_number;
    private JLabel label_low_ranking;
    private JLabel label_high_ranking;
    private JTextField countryInput;
    private JTextField minRateNumInput;
    private JTextField lowRankInput;
    private JTextField highRankInput;
    private JLabel label_order;
    private JComboBox<String> comboBox;
    private JButton btnSearch;
    private JScrollPane resultScrPane;
    private JTable resultTable;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    Vector<Vector<String>> vData;
    Vector<String> vName;
    DefaultTableModel model;
    // Used in retrieving
    private XMLReader reader;
    Vector<Vector<String>> movies;

    private void initTable() {
        resultTable = new JTable();
        vData = new Vector<>();
        vName = new Vector<>();
        resultScrPane = new JScrollPane(resultTable);
    }

    public static void main(String[] args) {
        testUI myWindow = new testUI();
        myWindow.setVisible(true);
        myWindow.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void search() {
        boolean[] flags = {lowRatingInput.getText().isEmpty(), highRatingInput.getText().isEmpty(),
                lowYearInput.getText().isEmpty(), highYearInput.getText().isEmpty(),
                countryInput.getText().isEmpty(), minRateNumInput.getText().isEmpty(),
                lowRankInput.getText().isEmpty(), highRankInput.getText().isEmpty()};

        for (Movie m : ListHandler.movies.values()) {
            String name = m.getChinese_name();
            Vector<String> movie = new Vector<>();
            movie.add(name);
            movies.add(movie);

            if (!flags[0])
                if (Float.parseFloat(m.getRating()) < Float.parseFloat(lowRatingInput.getText())) {
                    movies.remove(movie);
                    continue;
                }
            if (!flags[1])
                if (Float.parseFloat(m.getRating()) > Float.parseFloat(highRatingInput.getText())) {
                    movies.remove(movie);
                    continue;
                }
            if (!flags[2])
                if (m.getRelease_year() < Integer.parseInt(lowYearInput.getText())) {
                    movies.remove(movie);
                    continue;
                }
            if (!flags[3])
                if (m.getRelease_year() > Integer.parseInt(highYearInput.getText())) {
                    movies.remove(movie);
                    continue;
                }
            if (!flags[4])
                if (!Objects.equals(m.getCountry(), countryInput.getText())) {
                    movies.remove(movie);
                    continue;
                }
            if (!flags[5])
                if (m.getNumber() < Integer.parseInt(minRateNumInput.getText())) {
                    movies.remove(movie);
                    continue;
                }
            if (!flags[6])
                if (m.getRanking() > Integer.parseInt(lowRankInput.getText())) {
                    movies.remove(movie);
                    continue;
                }
            if (!flags[7])
                if (m.getRanking() < Integer.parseInt(highRankInput.getText())) {
                    movies.remove(movie);
                }
        }

        vData.addAll(movies);
    }

    // 首先处理排序
    private void retrieve() {
        vName.clear();
        vData.clear();

        // 建立与XML文档的连接
        try {
            //创建解析工厂
            SAXParserFactory factory = SAXParserFactory.newInstance();
            //得到解析器
            SAXParser sp = factory.newSAXParser();
            //得到解读器
            reader = sp.getXMLReader();
            //设置内容处理器
            reader.setContentHandler(new ListHandler());
            //读取xml的文档内容
            reader.parse("movies.xml");
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }

        movies = new Vector<>();

        switch (comboBox.getSelectedIndex()) {
            case 0:
                vName.add("符合条件的电影");
                search();
                break;
            case 1:
                vName.add("国家");
                vName.add("电影名");
                for (Movie m : ListHandler.movies.values()) {
                    Vector<String> movie = new Vector<>();
                    movie.add(m.getCountry());
                    movie.add(m.getChinese_name());
                    movies.add(movie);
                }
                movies.sort((v1, v2) -> {
                    String s1 = v1.get(0);
                    String s2 = v2.get(0);
                    return Integer.compare(s1.compareTo(s2), 0);
                });
                vData.addAll(movies);
                break;
            case 2:
                vName.add("电影名");
                vName.add("豆瓣评分");
                for (Movie m : ListHandler.movies.values()) {
                    Vector<String> movie = new Vector<>();
                    movie.add(m.getChinese_name());
                    movie.add(m.getRating());
                    movies.add(movie);
                }
                movies.sort((v1, v2) -> {
                    float f1 = Float.parseFloat(v1.get(1));
                    float f2 = Float.parseFloat(v2.get(1));
                    return Float.compare(f2, f1);
                });
                vData.addAll(movies);
                break;
            case 3:
                vName.add("电影名");
                vName.add("类型");
                for (Movie m : ListHandler.movies.values()) {
                    Vector<String> movie = new Vector<>();
                    movie.add(m.getChinese_name());
                    movie.add(m.getGenre()[0]);
                    movies.add(movie);
                }
                movies.sort((v1, v2) -> {
                    String s1 = v1.get(1);
                    String s2 = v2.get(1);
                    return Integer.compare(s1.compareTo(s2), 0);
                });
                vData.addAll(movies);
                break;
            default:
                break;
        }
        model = new DefaultTableModel(vData, vName);
        resultTable.setModel(model);
    }
}

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;

import java.util.HashMap;

public class ListHandler implements ContentHandler {

    static HashMap<Integer, Movie> movies = new HashMap<>();
    private Movie movieTemp = new Movie();
    private int flag = 7;//标记字符串为哪个标签下的
    //0表示Chinese_name 1表示English_name 2表示导演 3表示演员 4表示简介 5表示短评 7表示null


    /**
     * 当读取到第一个元素时开始做什么
     */

    @Override
    public void startElement(String uri, String localName, String qName,
                             Attributes attributes) {
        if (qName.equals("movie")) {
            int ranking = Integer.parseInt(attributes.getValue(0));
            String IMDb = attributes.getValue(1);
            String country = attributes.getValue(2);
            int release_year = Integer.parseInt(attributes.getValue(3));
            String img = attributes.getValue(4);
            movieTemp.setRanking(ranking);
            movieTemp.setIMDb(IMDb);
            movieTemp.setCountry(country);
            movieTemp.setRelease_year(release_year);
            movieTemp.setImg(img);
        }
        if (qName.equals("Chinese_name")) {
            flag = 0;
        }
        if (qName.equals("English_name")) {
            flag = 1;
        }
        if (qName.equals("director")) {
            flag = 2;
        }
        if (qName.equals("actor")) {
            flag = 3;
        }
        if (qName.equals("genre")) {
            String genre = attributes.getValue(0);
            movieTemp.setGenre(genre);
        }
        if (qName.equals("language")) {
            String language = attributes.getValue(0);
            movieTemp.setLanguage(language);
        }
        if (qName.equals("introduction")) {
            flag = 4;
        }
        if (qName.equals("review")) {
            String rating = attributes.getValue(0);
            int number = Integer.parseInt(attributes.getValue(1));
            movieTemp.setRating(rating);
            movieTemp.setNumber(number);
            flag = 5;
        }

    }

    /**
     * 表示读取到第一个元素结尾时做什么
     */
    @Override
    public void endElement(String uri, String localName, String qName) {
        if (qName.equals("movie")) {
            movies.put(movieTemp.getRanking(), movieTemp);
            movieTemp = new Movie();
        }

    }

    /**
     * 表示读取字符串时做什么
     */
    @Override
    public void characters(char[] ch, int start, int length) {
//        System.out.print(new String(ch,start,length));
        String str = new String(ch, start, length);
        if (str.equals("\n\t"))
            return;
        //0表示Chinese_name   1表示English_name 2表示导演   3表示演员   4表示简介   5表示短评 7表示null
        switch (flag) {
            case 0:
                movieTemp.setChinese_name(str);
                flag = 7;
                break;
            case 1:
                movieTemp.setEnglish_name(str);
                flag = 7;
                break;
            case 2:
                movieTemp.setDirector(str);
                flag = 7;
                break;
            case 3:
                movieTemp.setActor(str);
                flag = 7;
                break;
            case 4:
                movieTemp.setIntroduction(str);
                flag = 7;
                break;
            case 5:
                movieTemp.setReview(str);
                flag = 7;
                break;
        }
    }

    @Override
    public void setDocumentLocator(Locator locator) {
        // TODO Auto-generated method stub

    }

    @Override
    public void startDocument() {
        // TODO Auto-generated method stub

    }

    @Override
    public void endDocument() {
        // TODO Auto-generated method stub

    }

    @Override
    public void startPrefixMapping(String prefix, String uri) {
        // TODO Auto-generated method stub

    }

    @Override
    public void endPrefixMapping(String prefix) {
        // TODO Auto-generated method stub

    }


    @Override
    public void ignorableWhitespace(char[] ch, int start, int length) {
        // TODO Auto-generated method stub

    }

    @Override
    public void processingInstruction(String target, String data) {
        // TODO Auto-generated method stub

    }

    @Override
    public void skippedEntity(String name) {
        // TODO Auto-generated method stub

    }
}
